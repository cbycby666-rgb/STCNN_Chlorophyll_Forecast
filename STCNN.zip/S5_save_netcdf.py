"""
S5 输出NetCDF预测结果
字段：time, lon, lat, chlorophyll, uncertainty
"""
import numpy as np
import xarray as xr
import torch
import torch.nn.functional as F

# ========== 1. 加载预测结果和原始坐标 ==========
print("加载预测结果...")
pred = np.load('data_processed/prediction_results.npz')
pred_mean = pred['pred_mean']    # (8样本, 7天, 120, 160) 降采样分辨率
pred_std = pred['pred_std']      # 不确定性
mask = pred['mask']

# 从原始数据获取经纬度坐标
ds_raw = xr.open_dataset('data_processed/merged_data.nc')
lat = ds_raw.latitude.values   # 241
lon = ds_raw.longitude.values  # 320
times = ds_raw.time.values     # 61天

print(f"预测形状: {pred_mean.shape}, 原始纬度: {len(lat)}, 经度: {len(lon)}")

# ========== 2. 上采样回原始分辨率 ==========
print("上采样回原始分辨率...")
def upsample(x, target_h, target_w):
    # x: (N, T, H, W)
    N, T, H, W = x.shape
    x = x.reshape(N*T, 1, H, W)
    x = F.interpolate(torch.FloatTensor(x), size=(target_h, target_w), mode='bilinear', align_corners=False)
    return x.numpy().reshape(N, T, target_h, target_w)

pred_mean_full = upsample(pred_mean, len(lat), len(lon))
pred_std_full = upsample(pred_std, len(lat), len(lon))
print(f"上采样后: {pred_mean_full.shape}")

# ========== 3. 取测试集对应的时间 ==========
# 测试集是最后8个样本，每个样本预测未来7天
# 测试集起始时间 = 总天数 - 测试样本数 - 输入天数
n_test = pred_mean.shape[0]
time_step = 7
test_start_idx = len(times) - n_test - time_step
test_times = times[test_start_idx + time_step:]  # 预测的时间点

# 把8个样本的7天预测拼接成时间序列
# 每个样本预测7天，相邻样本重叠，取每个时间点最后一个预测
all_pred = np.full((len(times), len(lat), len(lon)), np.nan)
all_uncert = np.full((len(times), len(lat), len(lon)), np.nan)

for i in range(n_test):
    start = test_start_idx + time_step + i
    for d in range(7):
        t_idx = start + d
        if t_idx < len(times):
            all_pred[t_idx] = pred_mean_full[i, d]
            all_uncert[t_idx] = pred_std_full[i, d]

# 只保留有预测的时间步
valid_mask = ~np.isnan(all_pred[:, 0, 0])
pred_times = times[valid_mask]
pred_values = all_pred[valid_mask]
uncert_values = all_uncert[valid_mask]
print(f"输出时间步数: {len(pred_times)}")

# ========== 4. 陆地格点设为NaN ==========
land_mask = np.isnan(ds_raw['chl'].values[0])  # 原始数据中陆地是NaN
pred_values[:, land_mask] = np.nan
uncert_values[:, land_mask] = np.nan

# ========== 5. 保存为NetCDF ==========
print("保存NetCDF...")
ds_out = xr.Dataset(
    {
        'chlorophyll': (['time', 'lat', 'lon'], pred_values.astype(np.float32)),
        'uncertainty': (['time', 'lat', 'lon'], uncert_values.astype(np.float32)),
    },
    coords={
        'time': pred_times,
        'lat': lat.astype(np.float32),
        'lon': lon.astype(np.float32),
    }
)

# 添加属性说明
ds_out['chlorophyll'].attrs = {'units': 'mg/m³', 'long_name': 'Chlorophyll-a concentration prediction'}
ds_out['uncertainty'].attrs = {'units': 'mg/m³', 'long_name': 'Prediction uncertainty (1 sigma)', 'method': 'MC Dropout with 30 samples'}
ds_out.attrs = {
    'title': 'STCNN Chlorophyll Forecast for China Coastal Waters',
    'model': 'STCNN (Spatio-Temporal CNN)',
    'input_features': 'chl, fe, no3, po4, si, uo, vo',
    'prediction_horizon': '7 days',
    'created': '2026-09-14',
}

output_path = 'chlorophyll_forecast.nc'
ds_out.to_netcdf(output_path)
print(f"已保存到: {output_path}")
print(f"包含字段: time, lat, lon, chlorophyll, uncertainty")
print(f"时间范围: {pred_times[0]} 到 {pred_times[-1]}")
print("完成！")
