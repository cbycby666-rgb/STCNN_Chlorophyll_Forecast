"""
S4 测试评估 + 不确定性分析（MC Dropout）
计算RMSE/MAE/R²，用MC Dropout估算置信区间
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# ========== 参数 ==========
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
MC_SAMPLES = 30  # MC Dropout采样次数（越多不确定性越准）

# ========== 1. 加载数据 ==========
print("加载数据...")
data = np.load('data_processed/train_data.npz', allow_pickle=True)
test_x, test_y = data['test_x'], data['test_y']
mask = data['mask']
means, stds = data['means'], data['stds']
print(f"测试集: {test_x.shape}")

# 空间降采样2倍（跟训练一致）
def downsample(x):
    N, C, T, H, W = x.shape
    x = x.reshape(N*C, T, H, W)
    x = F.avg_pool2d(torch.FloatTensor(x), 2)
    _, T2, H2, W2 = x.shape
    return x.reshape(N, C, T2, H2, W2).numpy()

test_x_ds = downsample(test_x)
test_y_ds = downsample(test_y[:, None])[:, 0]
mask_ds = F.avg_pool2d(torch.FloatTensor(mask[None, None]), 2).numpy()[0, 0]
mask_ds = (mask_ds > 0.5).astype(np.float32)
print(f"降采样后: {test_x_ds.shape}")

# ========== 2. 模型（跟训练时一样） ==========
class STCNN(nn.Module):
    def __init__(self, in_ch=7, pred_days=7, dropout=0.3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv3d(in_ch, 32, 3, padding=1), nn.BatchNorm3d(32), nn.ReLU(), nn.Dropout3d(dropout),
            nn.Conv3d(32, 64, 3, padding=1), nn.BatchNorm3d(64), nn.ReLU(), nn.Dropout3d(dropout),
            nn.Conv3d(64, 64, 3, padding=1), nn.BatchNorm3d(64), nn.ReLU(),
        )
        self.output = nn.Conv3d(64, pred_days, kernel_size=(7, 3, 3), padding=(0, 1, 1))
    def forward(self, x):
        x = self.features(x)
        x = self.output(x)
        return x.squeeze(2)

# ========== 3. MC Dropout不确定性预测 ==========
print(f"\nMC Dropout预测（{MC_SAMPLES}次采样）...")
model = STCNN().to(DEVICE)
model.load_state_dict(torch.load('data_processed/best_model.pth', map_location=DEVICE))
print("模型加载完成")

model.train()  # 保持train模式，Dropout才会生效
  # 保持train模式，Dropout才会生效
x_tensor = torch.FloatTensor(test_x_ds).to(DEVICE)

predictions = []
with torch.no_grad():
    for i in range(MC_SAMPLES):
        pred = model(x_tensor).cpu().numpy()
        predictions.append(pred)
        if (i+1) % 10 == 0:
            print(f"  已完成 {i+1}/{MC_SAMPLES}")

predictions = np.array(predictions)  # (30, 8, 7, lat, lon)
pred_mean = predictions.mean(axis=0)   # 均值预测 (8, 7, lat, lon)
pred_std = predictions.std(axis=0)     # 标准差=不确定性 (8, 7, lat, lon)

# ========== 4. 反标准化（回到原始叶绿素值） ==========
means_dict = data['means'].item()
stds_dict = data['stds'].item()
chl_mean = means_dict['chl']
chl_std = stds_dict['chl']
pred_mean_raw = np.expm1(pred_mean * chl_std + chl_mean)  # 反log+反标准化
test_y_raw = np.expm1(test_y_ds * chl_std + chl_mean)
pred_std_raw = pred_std * chl_std  # 不确定性也反标准化

# ========== 5. 计算评估指标（只在海洋格点） ==========
print("\n===== 评估指标 =====")
ocean_mask = mask_ds > 0  # 只算海洋格点

for day in range(7):
    p = pred_mean_raw[:, day][:, ocean_mask]
    t = test_y_raw[:, day][:, ocean_mask]
    rmse = np.sqrt(np.mean((p - t)**2))
    mae = np.mean(np.abs(p - t))
    # 皮尔逊相关系数R
    r = np.corrcoef(p.flatten(), t.flatten())[0, 1]
    print(f"第{day+1}天: RMSE={rmse:.4f} mg/m³ | MAE={mae:.4f} | R={r:.4f}")

# 整体（7天平均）
p_all = pred_mean_raw[:, :, ocean_mask]
t_all = test_y_raw[:, :, ocean_mask]
rmse_all = np.sqrt(np.mean((p_all - t_all)**2))
mae_all = np.mean(np.abs(p_all - t_all))
r_all = np.corrcoef(p_all.flatten(), t_all.flatten())[0, 1]
print(f"\n整体(7天平均): RMSE={rmse_all:.4f} | MAE={mae_all:.4f} | R={r_all:.4f}")

# 不确定性统计
print(f"\n不确定性（预测标准差）: 均值={pred_std_raw[:, :, ocean_mask].mean():.4f}, 最大={pred_std_raw[:, :, ocean_mask].max():.4f}")

# ========== 6. 保存结果 ==========
np.savez('data_processed/prediction_results.npz',
         pred_mean=pred_mean_raw, pred_std=pred_std_raw,
         test_y=test_y_raw, mask=mask_ds,
         rmse=rmse_all, mae=mae_all, r=r_all)
print("\n预测结果已保存到 data_processed/prediction_results.npz")
print("评估完成！")
