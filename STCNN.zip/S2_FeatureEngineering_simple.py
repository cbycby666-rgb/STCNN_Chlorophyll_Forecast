"""
S2 特征工程 - 适配Copernicus合并数据
从merged_data.nc构造训练样本：过去7天7个变量 → 未来7天叶绿素
"""
import xarray as xr
import numpy as np
import os

# ========== 参数设置 ==========
TIME_STEP = 7          # 输入天数（过去7天）
PREDICTION_DAYS = 7    # 预测天数（未来7天）
INPUT_VARS = ['chl', 'fe', 'no3', 'po4', 'si', 'uo', 'vo']  # 输入的7个变量
LABEL_VAR = 'chl'      # 预测目标（叶绿素）

# ========== 1. 读取合并数据 ==========
print("读取合并数据...")
ds = xr.open_dataset('data_processed/merged_data.nc')
print(f"数据维度: time={ds.dims['time']}, lat={ds.dims['latitude']}, lon={ds.dims['longitude']}")

# ========== 2. 处理NaN值（陆地格点） ==========
print("处理NaN值...")
data_dict = {}
for var in INPUT_VARS:
    data = ds[var].values  # shape: (时间, 纬度, 经度)
    data = np.nan_to_num(data, nan=0.0)  # 陆地NaN填0
    data_dict[var] = data
    print(f"  {var}: shape={data.shape}, min={data.min():.4f}, max={data.max():.4f}")

# 生成海洋mask（有数据的地方=1，陆地=0）
mask = (~np.isnan(ds[LABEL_VAR].values[0])).astype(np.float32)
print(f"海洋格点比例: {mask.mean():.1%}")

# ========== 3. 叶绿素做log变换 ==========
# 叶绿素值范围0.02~80+，跨度4000倍，log变换压缩范围
print("对叶绿素做log变换...")
data_dict['chl'] = np.log1p(data_dict['chl'])

# ========== 4. 标准化（每个变量减均值除标准差） ==========
print("标准化特征...")
means = {}
stds = {}
for var in INPUT_VARS:
    data = data_dict[var]
    ocean_data = data[:, mask > 0]  # 只在海洋格点上算
    mean = ocean_data.mean()
    std = ocean_data.std() + 1e-8
    data_dict[var] = (data - mean) / std
    means[var] = mean
    stds[var] = std
    print(f"  {var}: mean={mean:.4f}, std={std:.4f}")

# ========== 5. 滑动窗口构造样本 ==========
n_time = ds.dims['time']
n_samples = n_time - TIME_STEP - PREDICTION_DAYS + 1
print(f"\n构造样本: {n_time}天 → {n_samples}个样本")

features_list = []
labels_list = []

for i in range(n_samples):
    # 输入：过去7天 × 7个变量 → (7变量, 7天, 纬度, 经度)
    feat = np.stack([data_dict[var][i:i+TIME_STEP] for var in INPUT_VARS], axis=0)
    features_list.append(feat)
    # 标签：未来7天 × 叶绿素 → (7天, 纬度, 经度)
    label = data_dict[LABEL_VAR][i+TIME_STEP:i+TIME_STEP+PREDICTION_DAYS]
    labels_list.append(label)
    if (i+1) % 10 == 0:
        print(f"  已处理 {i+1}/{n_samples}")

features = np.stack(features_list, axis=0)  # (样本数, 7变量, 7天, 纬度, 经度)
labels = np.stack(labels_list, axis=0)      # (样本数, 7天, 纬度, 经度)
print(f"\n特征形状: {features.shape}")
print(f"标签形状: {labels.shape}")

# ========== 6. 划分训练/验证/测试集 ==========
n_train = int(n_samples * 0.7)
n_val = int(n_samples * 0.15)
n_test = n_samples - n_train - n_val
print(f"\n数据集划分: 训练={n_train}, 验证={n_val}, 测试={n_test}")

train_x, train_y = features[:n_train], labels[:n_train]
val_x, val_y = features[n_train:n_train+n_val], labels[n_train:n_train+n_val]
test_x, test_y = features[n_train+n_val:], labels[n_train+n_val:]

# ========== 7. 保存 ==========
os.makedirs('data_processed', exist_ok=True)
output_path = 'data_processed/train_data.npz'
np.savez(output_path,
         train_x=train_x, train_y=train_y,
         val_x=val_x, val_y=val_y,
         test_x=test_x, test_y=test_y,
         mask=mask, means=means, stds=stds,
         input_vars=INPUT_VARS, label_var=LABEL_VAR,
         time_step=TIME_STEP, prediction_days=PREDICTION_DAYS)

print(f"\n已保存到: {output_path}")
print("特征工程完成！")
