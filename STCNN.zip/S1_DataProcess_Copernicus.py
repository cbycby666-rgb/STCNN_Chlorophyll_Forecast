"""
S1 数据预处理 - 适配Copernicus合并NetCDF格式
读取叶绿素、营养盐、海流三个文件，对齐网格，合并保存
"""
import xarray as xr
import numpy as np
import os

# ========== 1. 读取三个数据文件 ==========
bgc_dir = 'data_raw/bgc'
phy_dir = 'data_raw/phy'

# 找到叶绿素文件（pft）和营养盐文件（nut）
pft_file = [f for f in os.listdir(bgc_dir) if 'pft' in f and f.endswith('.nc')][0]
nut_file = [f for f in os.listdir(bgc_dir) if 'nut' in f and f.endswith('.nc')][0]
phy_file = [f for f in os.listdir(phy_dir) if f.endswith('.nc')][0]

print(f"读取叶绿素: {pft_file}")
ds_chl = xr.open_dataset(os.path.join(bgc_dir, pft_file))
print(f"读取营养盐: {nut_file}")
ds_nut = xr.open_dataset(os.path.join(bgc_dir, nut_file))
print(f"读取海流: {phy_file}")
ds_phy = xr.open_dataset(os.path.join(phy_dir, phy_file))

# ========== 2. 去掉depth维度（都是表层0.49m） ==========
ds_chl = ds_chl.squeeze('depth')
ds_nut = ds_nut.squeeze('depth')
ds_phy = ds_phy.squeeze('depth')

# ========== 3. 海流降采样到0.25度（跟BGC对齐） ==========
# BGC的经纬度网格
target_lat = ds_chl.latitude.values
target_lon = ds_chl.longitude.values

# 用插值把海流从0.083度降到0.25度
ds_phy_interp = ds_phy.interp(latitude=target_lat, longitude=target_lon)
print("海流降采样完成")

# ========== 4. 合并所有变量 ==========
ds_merged = xr.merge([ds_chl, ds_nut, ds_phy_interp], compat='override')
print(f"合并后变量: {list(ds_merged.data_vars)}")
print(f"合并后维度: {dict(ds_merged.dims)}")

# ========== 5. 统计NaN情况 ==========
for var in ds_merged.data_vars:
    nan_ratio = float(ds_merged[var].isnull().mean())
    print(f"  {var}: NaN比例 = {nan_ratio:.1%}")

# ========== 6. 保存 ==========
os.makedirs('data_processed', exist_ok=True)
output_path = 'data_processed/merged_data.nc'
ds_merged.to_netcdf(output_path)
print(f"\n已保存到: {output_path}")
print("数据预处理完成！")
