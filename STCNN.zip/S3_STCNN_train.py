"""
S3 STCNN模型训练 - 修复版
修复输出维度bug，加入BatchNorm/Dropout/学习率调度，只在海洋格点计算loss
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import time

# ========== 参数设置 ==========
BATCH_SIZE = 4
EPOCHS = 10
LR = 0.001
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {DEVICE}")

# ========== 1. 加载数据 ==========
print("加载训练数据...")
data = np.load('data_processed/train_data.npz')
train_x, train_y = data['train_x'], data['train_y']
val_x, val_y = data['val_x'], data['val_y']
mask = data['mask']
print(f"训练集: {train_x.shape}, 验证集: {val_x.shape}")

train_loader = DataLoader(TensorDataset(torch.FloatTensor(train_x), torch.FloatTensor(train_y)),
                          batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.FloatTensor(val_x), torch.FloatTensor(val_y)),
                        batch_size=BATCH_SIZE, shuffle=False)
mask_tensor = torch.FloatTensor(mask).to(DEVICE)

# ========== 2. STCNN模型定义 ==========
class STCNN(nn.Module):
    """时空卷积神经网络：3D卷积同时处理时间和空间"""
    def __init__(self, in_ch=7, pred_days=7, dropout=0.3):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv3d(in_ch, 32, 3, padding=1), nn.BatchNorm3d(32), nn.ReLU(), nn.Dropout3d(dropout),
            nn.Conv3d(32, 64, 3, padding=1),  nn.BatchNorm3d(64), nn.ReLU(), nn.Dropout3d(dropout),
            nn.Conv3d(64, 64, 3, padding=1),  nn.BatchNorm3d(64), nn.ReLU(),
        )
        # 关键修复：kernel_size=(7,3,3)把时间维7天压缩成1天，空间保持不变
        self.output = nn.Conv3d(64, pred_days, kernel_size=(7, 3, 3), padding=(0, 1, 1))

    def forward(self, x):
        x = self.features(x)   # (batch, 64, 7天, lat, lon)
        x = self.output(x)     # (batch, 7天, 1, lat, lon)
        return x.squeeze(2)    # (batch, 7天, lat, lon)

model = STCNN().to(DEVICE)
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=LR)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5, factor=0.5)
print(f"模型参数量: {sum(p.numel() for p in model.parameters()):,}")

# ========== 3. 训练循环 ==========
best_val = float('inf')
print("\n开始训练（CPU训练较慢，请耐心等待）...")
for epoch in range(EPOCHS):
    t0 = time.time()
    # 训练
    model.train()
    tr_loss = 0
    for bx, by in train_loader:
        bx, by = bx.to(DEVICE), by.to(DEVICE)
        optimizer.zero_grad()
        pred = model(bx)
        loss = criterion(pred * mask_tensor, by * mask_tensor)  # 只在海洋格点算loss
        loss.backward()
        optimizer.step()
        tr_loss += loss.item()
    tr_loss /= len(train_loader)
    # 验证
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for bx, by in val_loader:
            bx, by = bx.to(DEVICE), by.to(DEVICE)
            pred = model(bx)
            val_loss += criterion(pred * mask_tensor, by * mask_tensor).item()
    val_loss /= len(val_loader)
    scheduler.step(val_loss)
    # 保存最佳模型
    if val_loss < best_val:
        best_val = val_loss
        torch.save(model.state_dict(), 'data_processed/best_model.pth')
    print(f"Epoch {epoch+1:2d}/{EPOCHS} | train: {tr_loss:.6f} | val: {val_loss:.6f} | {time.time()-t0:.0f}s")

print(f"\n训练完成！最佳验证loss: {best_val:.6f}")
print("模型已保存到 data_processed/best_model.pth")

